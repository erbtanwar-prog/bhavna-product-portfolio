BHAVNA TANWAR — INTERVIEW-READY PORTFOLIO

FILES
- index.html: the complete responsive portfolio site. It has no build step or external dependencies.

BEFORE DEPLOYING
1. Open index.html in a browser and review the content.
2. Confirm the exact programme title/status against your certificate.
3. If you want a resume download button, add your latest resume PDF in this folder named resume.pdf and add a link to it on the page. No resume PDF is included because the latest file was not supplied in this package.
4. Check that email and LinkedIn links are correct.

DEPLOY TO VERCEL USING A NEW PROJECT
1. Go to https://vercel.com/new and sign in.
2. For a simple static HTML site, use the manual deployment / Vercel CLI route available to your account. Vercel's UI options can change; follow the current prompts.
3. Easiest reliable path if Vercel asks for a Git repository: create a new GitHub repository, upload index.html to the repository root, then import that repository into Vercel. Framework preset: Other. Build command: leave blank. Output directory: leave blank / default for a root static HTML site.
4. Deploy and test the generated *.vercel.app URL on desktop and mobile.
5. Only after testing, optionally add a custom domain. Keep the existing bhavnaresume.vercel.app domain untouched unless you deliberately decide to move it.

CONTENT INTEGRITY
- Unacademy title is represented as Category Manager, not Product Manager.
- Category-level metrics are explicitly not attributed to a single feature.
- MakeMyTrip AI Trip Assistant is described as an academic capstone, not a live product launch.
